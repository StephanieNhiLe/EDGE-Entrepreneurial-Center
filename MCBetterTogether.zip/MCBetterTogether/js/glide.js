var glideMulti = new Glide('.glide', {
    type: "carousel",
    // animationDuration: 1500,
    autoplay: 3500,
    perView: 3
});

// glideMulti.mount();